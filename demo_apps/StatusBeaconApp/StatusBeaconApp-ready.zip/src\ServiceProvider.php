<?php

namespace Apps\Statusbeacon;

use Apps\BaseAppServiceProvider;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

class ServiceProvider extends BaseAppServiceProvider
{
    public static function getSchema(): array
    {
        return [
            'title' => 'Status Beacon settings',
            'fields' => [
                [
                    'name' => 'show_uptime',
                    'type' => 'boolean',
                    'default' => true,
                    'label' => 'Show session uptime',
                ],
                [
                    'name' => 'refresh_seconds',
                    'type' => 'number',
                    'default' => 30,
                    'label' => 'Refresh interval (seconds)',
                ],
            ],
        ];
    }

    public function registerRoutes(): void
    {
        Route::middleware('auth')->get('/apps/statusbeacon/ping', function () {
            return response()->json([
                'ok' => true,
                'server_time' => now()->toDateTimeString(),
                'user' => Auth::user()?->name,
            ]);
        })->name('apps.statusbeacon.ping');
    }

    public function render(array $data = [])
    {
        $tips = [
            'Проверьте сценарии с таймерами перед сном.',
            'Вынесите критичные устройства в отдельный виджет.',
            'Проверьте подтверждение email для уведомлений.',
            'Давайте понятные имена устройствам и сценам.',
        ];

        return view('apps.Statusbeacon.dashboard', [
            'userName' => Auth::user()?->name ?? 'User',
            'serverTime' => now()->format('Y-m-d H:i:s'),
            'tip' => $tips[array_rand($tips)],
        ])->render();
    }
}
